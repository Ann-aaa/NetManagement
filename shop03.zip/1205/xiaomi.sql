/*
Navicat MySQL Data Transfer

Source Server         : hxk
Source Server Version : 50540
Source Host           : 127.0.0.1:3306
Source Database       : xiaomi

Target Server Type    : MYSQL
Target Server Version : 50540
File Encoding         : 65001

Date: 2019-12-05 09:26:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cms_menu
-- ----------------------------
DROP TABLE IF EXISTS `cms_menu`;
CREATE TABLE `cms_menu` (
  `menu_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '权限ID',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父级编号',
  `menu_type` tinyint(2) DEFAULT NULL COMMENT '权限类型 1=菜单/2=功能/3=子功能/0=操作',
  `menu_code` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '权限代码',
  `menu_name` varchar(64) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '权限名称',
  `sort` int(9) DEFAULT NULL COMMENT '排序',
  `href` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '链接地址',
  `icon` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '图标名称',
  `status` tinyint(2) DEFAULT NULL COMMENT '状态 0=隐藏/1=显示',
  `permission` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '权限标识',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remarks` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COMMENT='目录表';

-- ----------------------------
-- Records of cms_menu
-- ----------------------------
INSERT INTO `cms_menu` VALUES ('1', '0', null, '', '功能菜单', null, '', '', '1', '', '2016-10-23 16:50:34', '2016-12-08 16:14:48', '主页');
INSERT INTO `cms_menu` VALUES ('2', '1', '1', 'administrator', '管理员管理', '100', '/administrator', 'user', '1', null, '2016-10-23 17:08:23', '2016-10-23 17:08:27', '');
INSERT INTO `cms_menu` VALUES ('3', '2', '2', 'list', '管理员列表', '20', '/administrator/list/view', 'users', '1', '', '2016-10-23 17:24:24', '2016-12-10 06:22:36', '');
INSERT INTO `cms_menu` VALUES ('4', '3', '0', 'list_view', '查看', '1', '/administrator/list/view', '', '1', 'administrator:list:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', '');
INSERT INTO `cms_menu` VALUES ('5', '3', '0', 'list_edit', '编辑', '2', '/administrator/list/edit', '', '1', 'administrator:list:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', '');
INSERT INTO `cms_menu` VALUES ('6', '3', '0', 'list_delete', '删除', '3', '/administrator/list/delete', null, '1', 'administrator:list:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('7', '3', '0', 'list_create', '添加', '4', '/administrator/list/create', null, '1', 'administrator:list:create', '2016-10-23 17:50:45', '2016-10-23 17:50:52', null);
INSERT INTO `cms_menu` VALUES ('8', '2', '2', 'info', '个人信息', '10', '/administrator/info/view', 'user-times', '1', '', '2016-10-23 17:24:24', '2016-12-10 06:22:23', '');
INSERT INTO `cms_menu` VALUES ('9', '8', '0', 'info_view', '查看', '1', '/administrator/info/view', '', '1', 'administrator:info:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', '');
INSERT INTO `cms_menu` VALUES ('10', '8', '0', 'info_edit', '编辑', '2', '/administrator/info/edit', '', '1', 'administrator:info:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', '');
INSERT INTO `cms_menu` VALUES ('11', '2', '2', 'role', '角色管理', '30', '/administrator/role/view', 'user-secret', '1', '', '2016-10-23 17:24:24', '2016-12-08 17:21:33', '');
INSERT INTO `cms_menu` VALUES ('12', '11', '0', 'role_view', '查看', '1', '/administrator/role/view', '', '1', 'administrator:role:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', '');
INSERT INTO `cms_menu` VALUES ('13', '11', '0', 'role_edit', '编辑', '2', '/administrator/role/edit', '', '1', 'administrator:role:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', '');
INSERT INTO `cms_menu` VALUES ('14', '11', '0', 'role_delete', '删除', '3', '/administrator/role/delete', '', '1', 'administrator:role:delete', '2016-10-23 17:46:12', '2016-10-23 17:46:18', '');
INSERT INTO `cms_menu` VALUES ('15', '11', '0', 'role_create', '添加', '4', '/administrator/role/create', '', '1', 'administrator:role:create', '2016-10-23 17:47:14', '2016-10-23 17:47:23', '');
INSERT INTO `cms_menu` VALUES ('16', '1', '1', 'user', '会员管理', '300', '/system/user', 'users', '1', null, '2016-10-23 17:08:23', '2016-10-23 17:08:27', null);
INSERT INTO `cms_menu` VALUES ('17', '16', '2', 'list', '会员列表', '10', '/system/user/list/view', 'user', '1', '', '2016-10-23 17:24:24', '2016-12-10 06:15:37', '');
INSERT INTO `cms_menu` VALUES ('18', '17', '0', 'list_view', '查看', '1', '/system/user/list/view', null, '1', 'user:list:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('19', '17', '0', 'list_edit', '编辑', '2', '/system/user/list/edit', null, '1', 'user:list:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('20', '17', '0', 'list_delete', '删除', '3', '/system/user/list/delete', null, '1', 'user:list:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('21', '17', '0', 'list_add', '添加', '4', '/system/user/list/add', null, '1', 'user:list:add', '2016-10-23 17:50:45', '2016-10-23 17:50:52', null);
INSERT INTO `cms_menu` VALUES ('22', '16', '2', 'grade', '等级管理', '20', '/system/user/grade/view', '', '1', '', '2016-10-23 17:24:24', '2016-10-23 17:24:29', null);
INSERT INTO `cms_menu` VALUES ('23', '22', '0', 'grade_view', '查看', '1', '/system/user/grade/view', null, '1', 'user:grade:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('24', '22', '0', 'grade_edit', '编辑', '2', '/system/user/grade/edit', null, '1', 'user:grade:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('25', '16', '2', 'record', '会员记录管理', '30', '/system/user/record/view', '', '1', '', '2016-10-23 17:24:24', '2016-10-23 17:24:29', null);
INSERT INTO `cms_menu` VALUES ('26', '25', '0', 'record_view', '查看', '1', '/system/user/record/view', '', '1', 'user:record:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('27', '1', '1', 'product', '产品管理', '400', '/product', 'product-hunt', '1', null, '2016-10-23 17:08:23', '2017-05-20 06:58:07', '');
INSERT INTO `cms_menu` VALUES ('28', '27', '2', 'list', '产品列表', '10', '/product/list/view', 'fax', '1', '', '2016-10-23 17:24:24', '2017-05-20 07:00:31', '');
INSERT INTO `cms_menu` VALUES ('29', '28', '0', 'list_view', '查看', '1', '/product/list/view', null, '1', 'product:list:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('30', '28', '0', 'list_edit', '编辑', '2', '/product/list/edit', null, '1', 'product:list:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('31', '28', '0', 'list_delete', '删除', '3', '/product/list/delete', null, '1', 'product:list:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('32', '28', '0', 'list_add', '添加', '4', '/product/list/add', null, '1', 'product:list:add', '2016-10-23 17:50:45', '2016-10-23 17:50:52', null);
INSERT INTO `cms_menu` VALUES ('33', '27', '2', 'category', '分类管理', '20', '/product/category/view', 'object-ungroup', '1', '', '2016-10-23 17:24:24', '2017-05-20 07:04:06', '');
INSERT INTO `cms_menu` VALUES ('34', '33', '0', 'category_view', '查看', '1', '/product/category/view', null, '1', 'product:category:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('35', '33', '0', 'category_edit', '编辑', '2', '/product/category/edit', null, '1', 'product:category:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('36', '33', '0', 'category_delete', '删除', '3', '/product/category/delete', null, '1', 'product:category:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('37', '33', '0', 'category_create', '添加', '4', '/product/category/create', '', '1', 'product:category:create', '2016-10-23 17:50:45', '2017-06-07 17:01:10', '');
INSERT INTO `cms_menu` VALUES ('38', '27', '2', 'query', '问答管理', '30', '/system/goods/query', '', '1', '', '2016-10-23 17:24:24', '2016-10-23 17:24:29', null);
INSERT INTO `cms_menu` VALUES ('39', '38', '0', 'query_view', '查看', '1', '/system/goods/query/view', null, '1', 'goods:query:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('40', '38', '0', 'query_edit', '编辑', '2', '/system/goods/query/edit', null, '1', 'goods:query:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('41', '38', '0', 'query_delete', '删除', '3', '/system/goods/query/delete', null, '1', 'goods:query:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('42', '38', '0', 'query_add', '添加', '4', '/system/goods/query/add', null, '1', 'goods:query:add', '2016-10-23 17:50:45', '2016-10-23 17:50:52', null);
INSERT INTO `cms_menu` VALUES ('43', '1', '1', 'order', '交易管理', '500', '/system/order', 'money', '1', null, '2016-10-23 17:08:23', '2016-10-23 17:08:27', null);
INSERT INTO `cms_menu` VALUES ('44', '43', '2', 'list', '订单管理', '10', '/system/order/list', '', '1', '', '2016-10-23 17:24:24', '2016-10-23 17:24:29', null);
INSERT INTO `cms_menu` VALUES ('45', '44', '0', 'list_view', '查看', '1', '/system/order/list/view', null, '1', 'order:list:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('46', '44', '0', 'list_edit', '编辑', '2', '/system/order/list/edit', null, '1', 'order:list:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('47', '44', '0', 'list_delete', '删除', '3', '/system/order/list/delete', null, '1', 'order:list:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('48', '44', '0', 'list_add', '添加', '4', '/system/order/list/add', null, '1', 'order:list:add', '2016-10-23 17:50:45', '2016-10-23 17:50:52', null);
INSERT INTO `cms_menu` VALUES ('49', '43', '2', 'info', '交易信息', '10', '/system/order/info', '', '0', '', '2016-10-23 17:24:24', '2016-10-23 17:24:29', null);
INSERT INTO `cms_menu` VALUES ('50', '49', '0', 'info_view', '查看', '1', '/system/order/info/view', null, '0', 'goods:info:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('51', '43', '2', 'reviews', '评论管理', '10', '/system/order/reviews', '', '0', '', '2016-10-23 17:24:24', '2016-10-23 17:24:29', null);
INSERT INTO `cms_menu` VALUES ('52', '51', '0', 'reviews_view', '查看', '1', '/system/order/reviews/view', null, '0', 'goods:reviews:view', '2016-10-23 17:46:12', '2016-10-23 17:46:18', null);
INSERT INTO `cms_menu` VALUES ('53', '51', '0', 'reviews_edit', '编辑', '2', '/system/order/reviews/edit', null, '0', 'goods:reviews:edit', '2016-10-23 17:47:14', '2016-10-23 17:47:23', null);
INSERT INTO `cms_menu` VALUES ('54', '51', '0', 'reviews_delete', '删除', '3', '/system/order/reviews/delete', null, '0', 'goods:reviews:delete', '2016-10-23 17:48:40', '2016-10-23 17:48:47', null);
INSERT INTO `cms_menu` VALUES ('55', '51', '0', 'reviews_add', '添加', '4', '/system/order/reviews/add', null, '0', 'goods:reviews:add', '2016-10-23 17:50:45', '2016-10-23 17:50:52', null);
INSERT INTO `cms_menu` VALUES ('65', '1', '1', 'system', '系统管理', '700', '/system', 'universal-access', '1', null, '2016-10-23 20:22:55', '2016-10-23 20:23:02', '');
INSERT INTO `cms_menu` VALUES ('66', '65', '2', 'menu', '菜单管理', '10', '/system/menu/view', 'file-text', '1', '', '2016-10-23 17:24:24', '2016-12-08 17:22:33', '');
INSERT INTO `cms_menu` VALUES ('69', '3', '0', 'list_audit', '审查', '5', '/administrator/list/audit', '', '1', 'administrator:list:audit', '2016-10-25 17:25:29', '2016-10-25 17:25:35', '');
INSERT INTO `cms_menu` VALUES ('70', '17', '0', 'list_audit', '审查', '5', '/system/user/list/audit', null, '1', 'user:list:audit', '2016-10-25 17:25:29', '2016-10-25 17:25:35', null);
INSERT INTO `cms_menu` VALUES ('72', '28', '0', 'list_audit', '审查', '5', '/product/list/audit', null, '1', 'product:list:audit', '2016-10-25 17:25:29', '2016-10-25 17:25:35', null);
INSERT INTO `cms_menu` VALUES ('74', '66', '0', 'menu_view', '查看', '1', '/system/menu/view', null, '1', 'system:menu:view', '2016-12-05 16:08:59', '2016-12-05 16:09:05', null);
INSERT INTO `cms_menu` VALUES ('75', '66', '0', 'menu_edit', '编辑', '2', '/system/menu/edit', '', '1', 'system:menu:edit', '2016-12-05 16:08:59', '2016-12-10 06:45:32', '');
INSERT INTO `cms_menu` VALUES ('76', '66', '0', 'menu_delete', '删除', '3', '/system/menu/delete', null, '1', 'system:menu:delete', '2016-12-05 16:08:59', '2016-12-05 16:09:05', null);
INSERT INTO `cms_menu` VALUES ('77', '66', '0', 'menu_create', '添加', '4', '/system/menu/create', '', '1', 'system:menu:create', '2016-12-05 16:08:59', '2016-12-05 16:09:05', '');
INSERT INTO `cms_menu` VALUES ('78', '66', '0', 'menu_audit', '审查', '5', '/system/menu/audit', null, '1', 'system:menu:audit', '2016-12-05 16:08:59', '2016-12-05 16:09:05', null);
INSERT INTO `cms_menu` VALUES ('83', '11', '0', 'role_audit', '审查', '5', '/administrator/role/audit', '', '1', 'administrator:role:audit', '2016-12-10 07:25:58', '2016-12-10 07:26:56', '');
INSERT INTO `cms_menu` VALUES ('84', '65', '2', 'version', '版本日志', '20', '/system/version/view', 'file-text-o', '1', null, null, null, '系统版本日志');
INSERT INTO `cms_menu` VALUES ('85', '84', '0', 'version_view', '查看', '1', '/system/version/view', '', '1', 'system:version:view', null, null, '');
INSERT INTO `cms_menu` VALUES ('86', '2', '2', 'organization', '组织管理', '40', '/administrator/organization/view', 'coffee', '1', null, null, null, '组织管理');
INSERT INTO `cms_menu` VALUES ('87', '86', '0', 'organization_view', '查看', '1', '/administrator/organization/view', '', '1', 'administrator:organization:view', null, null, '');
INSERT INTO `cms_menu` VALUES ('88', '86', '0', 'organization_edit', '编辑', '2', '/administrator/organization/edit', '', '1', 'administrator:organization:edit', null, null, '');
INSERT INTO `cms_menu` VALUES ('89', '86', '0', 'organization_delete', '删除', '3', '/administrator/organization/delete', '', '1', 'administrator:organization:delete', null, null, '');
INSERT INTO `cms_menu` VALUES ('90', '86', '0', 'organization_audit', '审查', '5', '/administrator/organization/audit', '', '1', 'administrator:organization:audit', null, null, '');
INSERT INTO `cms_menu` VALUES ('91', '86', '0', 'organization_create', '添加', '4', '/administrator/organization/create', '', '1', 'administrator:organization:create', null, null, '');
INSERT INTO `cms_menu` VALUES ('93', '65', '2', 'swagger', 'Swagger', '30', '/swagger-ui.html', 'black-tie', '1', null, '2017-04-07 12:18:42', null, 'swagger API');
INSERT INTO `cms_menu` VALUES ('94', '1', '1', 'online', '内容管理', '600', 'online', 'bars', '1', null, '2017-04-08 17:12:36', null, '电子商城内容管理模块');
INSERT INTO `cms_menu` VALUES ('95', '94', '2', 'navigation', '导航管理', '10', '/online/navigation/view', 'line-chart', '1', null, '2017-04-08 17:14:48', null, '电子商城内容管理模块导航管理');
INSERT INTO `cms_menu` VALUES ('96', '95', '0', 'navigation_view', '查看', '1', '/online/navigation/view', '', '1', 'online:navigation:view', '2017-04-08 17:16:43', null, '');
INSERT INTO `cms_menu` VALUES ('97', '95', '0', 'navigation_edit', '编辑', '2', '/online/navigation/edit', '', '1', 'online:navigation:edit', '2017-04-08 17:17:45', null, '');
INSERT INTO `cms_menu` VALUES ('98', '95', '0', 'navigation_delete', '删除', '3', '/online/navigation/delete', '', '1', 'online:navigation:delete', '2017-04-08 17:19:16', null, '');
INSERT INTO `cms_menu` VALUES ('99', '95', '0', 'navigation_add', '添加', '4', '/online/navigation/create', '', '1', 'online:navigation:create', '2017-04-08 17:21:14', null, '');
INSERT INTO `cms_menu` VALUES ('100', '95', '0', 'navigation_audit', '审查', '5', '/online/navigation/audit', '', '1', 'online:navigation:audit', '2017-04-08 17:22:22', null, '');
INSERT INTO `cms_menu` VALUES ('101', '94', '2', 'advert', '广告管理', '20', '/online/advert/view', 'black-tie', '1', null, '2017-05-11 07:26:00', null, '');
INSERT INTO `cms_menu` VALUES ('102', '101', '0', 'advert_view', '查看', '1', '/online/advert/view', '', '1', 'online:advert:view', '2017-05-11 07:27:58', null, '');
INSERT INTO `cms_menu` VALUES ('103', '101', '0', 'advert_edit', '编辑', '2', '/online/advert/edit', '', '1', 'online:advert:edit', '2017-05-11 07:30:52', null, '');
INSERT INTO `cms_menu` VALUES ('104', '101', '0', 'advert_delete', '删除', '3', '/online/advert/delete', '', '1', 'online:advert:delete', '2017-05-11 07:32:12', null, '');
INSERT INTO `cms_menu` VALUES ('105', '101', '0', 'advert_add', '添加', '4', '/online/advert/create', '', '1', 'online:advert:create', '2017-05-11 07:33:00', null, '');
INSERT INTO `cms_menu` VALUES ('106', '101', '0', 'advert_audit', '审查', '5', '/online/advert/audit', '', '1', 'online:advert:audit', '2017-05-11 07:33:47', null, '');
INSERT INTO `cms_menu` VALUES ('107', '33', '0', 'category_audit', '审查', '5', '/product/category/audit', '', '1', 'product:category:audit', '2017-05-20 07:05:27', null, '');
INSERT INTO `cms_menu` VALUES ('108', '65', '2', 'druid', '数据监控', '40', '/druid', 'cc-jcb', '1', null, '2017-06-08 11:00:37', null, '');
INSERT INTO `cms_menu` VALUES ('109', '65', '2', 'log', '日志记录', '50', '/system/log/view', 'file-text', '1', '', '2017-06-09 04:46:38', null, '');
INSERT INTO `cms_menu` VALUES ('110', '109', '0', 'log_view', '查看', '1', '/system/log/view', '', '1', 'system:log:view', '2017-06-09 04:48:47', null, '');

-- ----------------------------
-- Table structure for os_address
-- ----------------------------
DROP TABLE IF EXISTS `os_address`;
CREATE TABLE `os_address` (
  `address_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '收获地址ID',
  `user_id` bigint(20) unsigned DEFAULT NULL COMMENT '用户ID',
  `user_name` varchar(64) DEFAULT NULL COMMENT '姓名',
  `user_tag` varchar(64) DEFAULT NULL COMMENT '地址标签',
  `user_phone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `user_adress` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL COMMENT '详细地址',
  `user_zipcode` int(6) DEFAULT NULL COMMENT '邮政编码',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='收获地址表';

-- ----------------------------
-- Records of os_address
-- ----------------------------
INSERT INTO `os_address` VALUES ('3', '1', '陈星星', '家', '18857105127', '海曙路58号', '111111', '2017-03-16 18:48:14', '2017-03-16 18:48:18');
INSERT INTO `os_address` VALUES ('25', '1', '陈星星', '学校', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 02:16:48', '2017-05-10 15:39:11');
INSERT INTO `os_address` VALUES ('26', '1', 'kjkjk', 'home', '11111111111', '我的天那那那', '444444', null, null);
INSERT INTO `os_address` VALUES ('27', '31', '司法', 'jia', '17853242597', '非机动车龙骑', '222111', null, null);
INSERT INTO `os_address` VALUES ('28', '32', '胡可', '学校', '17853242555', '山东省青岛市青岛大学', '222333', null, null);
INSERT INTO `os_address` VALUES ('32', '28', 'Anna', 'home', '17853241001', '山东省青岛市', '256434', null, null);
INSERT INTO `os_address` VALUES ('33', '35', '胡雪珂', '家', '17853243333', '山东省滨州市', '256506', null, null);
INSERT INTO `os_address` VALUES ('34', '35', '王森明', '学校', '17853241111', '山东省济南市', '267865', null, null);
INSERT INTO `os_address` VALUES ('35', '37', 'huxueke', '家', '17853245555', '山东省滨州市博兴县', '256521', null, null);

-- ----------------------------
-- Table structure for os_category
-- ----------------------------
DROP TABLE IF EXISTS `os_category`;
CREATE TABLE `os_category` (
  `category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '父分类ID',
  `name` varchar(64) DEFAULT NULL COMMENT '分类名称',
  `sort` int(9) DEFAULT NULL COMMENT '排序',
  `type` tinyint(2) DEFAULT NULL COMMENT '目录类型 2=二级目录/1=一级目录/0=总目录',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `page_title` varchar(64) DEFAULT NULL COMMENT '页面标题',
  `page_description` varchar(64) DEFAULT NULL COMMENT '页面描述',
  `page_keyword` varchar(64) DEFAULT NULL COMMENT '页面关键词',
  `remarks` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- ----------------------------
-- Records of os_category
-- ----------------------------
INSERT INTO `os_category` VALUES ('1', '0', '全部商品', null, '0', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '全部商品', null, null, null);
INSERT INTO `os_category` VALUES ('2', '1', '手机', '100', '1', '2017-02-25 21:44:43', '2017-06-08 07:06:07', '手机', '小米手机,超乎你的想象,性能超级棒;小米手机,超乎你的想象,性能超级棒.', '小米手机,超乎你的想象,性能超级棒', '小米手机');
INSERT INTO `os_category` VALUES ('3', '1', '智能硬件', '200', '1', '2017-02-25 21:44:43', '2017-06-08 06:51:01', '智能硬件', null, null, '');
INSERT INTO `os_category` VALUES ('4', '1', '笔记本  平板', '300', '1', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '笔记本/平板', null, null, null);
INSERT INTO `os_category` VALUES ('5', '1', '路由器  移动电源', '400', '1', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '路由器/移动电源', null, null, null);
INSERT INTO `os_category` VALUES ('6', '1', '周边配件', '500', '1', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '周边配件', null, null, null);
INSERT INTO `os_category` VALUES ('7', '1', '耳机  音响', '600', '1', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '耳机/音响', null, null, null);
INSERT INTO `os_category` VALUES ('8', '1', '保护套  贴膜', '700', '1', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '保护套/贴膜', null, null, null);
INSERT INTO `os_category` VALUES ('9', '1', '生活周边', '800', '1', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '生活周边', null, null, null);
INSERT INTO `os_category` VALUES ('10', '3', '手环及配件', '10', '2', '2017-02-25 21:44:43', '2017-06-08 06:48:38', '手环及配件', '手环及配件', '手环及配件', '手环及配件');
INSERT INTO `os_category` VALUES ('11', '3', '智能灯', '20', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '智能健康', null, null, null);
INSERT INTO `os_category` VALUES ('12', '3', '智能家居', '30', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '智能家居', null, null, null);
INSERT INTO `os_category` VALUES ('13', '3', '智能健康', '40', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '智能出行', null, null, null);
INSERT INTO `os_category` VALUES ('15', '4', '笔记本电脑', '10', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '笔记本电脑', null, null, null);
INSERT INTO `os_category` VALUES ('16', '4', '平板电脑', '20', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '平板电脑', null, null, null);
INSERT INTO `os_category` VALUES ('17', '5', '路由器', '10', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '路由器', null, null, null);
INSERT INTO `os_category` VALUES ('18', '5', '移动电源', '20', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '移动电源', null, null, null);
INSERT INTO `os_category` VALUES ('19', '5', '路由器配件', '30', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '路由器配件', null, null, null);
INSERT INTO `os_category` VALUES ('20', '6', '插线板', '10', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '插线板', null, null, null);
INSERT INTO `os_category` VALUES ('21', '6', '存储卡', '20', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '存储卡', null, null, null);
INSERT INTO `os_category` VALUES ('22', '6', '移动硬盘', '30', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '移动硬盘', null, null, null);
INSERT INTO `os_category` VALUES ('23', '7', '头戴式耳机', '10', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '头戴式耳机', null, null, null);
INSERT INTO `os_category` VALUES ('24', '7', '活塞耳机', '20', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '活塞耳机', null, null, null);
INSERT INTO `os_category` VALUES ('25', '7', '蓝牙耳机', '30', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '蓝牙耳机', null, null, null);
INSERT INTO `os_category` VALUES ('26', '7', '音响', '40', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '音响', null, null, null);
INSERT INTO `os_category` VALUES ('27', '8', '贴膜', '10', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '贴膜', null, null, null);
INSERT INTO `os_category` VALUES ('28', '8', '保护套  保护壳', '20', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '保护套/保护壳', null, null, null);
INSERT INTO `os_category` VALUES ('29', '8', '移动电源保护套', '30', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '移动电源保护套', null, null, null);
INSERT INTO `os_category` VALUES ('30', '9', '箱包', '10', '2', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '箱包', null, null, null);
INSERT INTO `os_category` VALUES ('31', '9', '服装', '20', '2', '2017-02-25 21:44:43', '2017-06-08 07:05:56', '服装', null, null, '');
INSERT INTO `os_category` VALUES ('32', '1', '智能家电', '900', '1', '2017-06-08 07:38:02', '2017-06-08 07:41:23', '智能家电', '智能家电', '智能家电', '智能家电');
INSERT INTO `os_category` VALUES ('33', '2', '小米手机', '5', '2', '2017-06-08 07:44:39', null, '小米手机', '小米手机', '小米手机', '小米手机');

-- ----------------------------
-- Table structure for os_order
-- ----------------------------
DROP TABLE IF EXISTS `os_order`;
CREATE TABLE `os_order` (
  `order_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_number` bigint(20) DEFAULT NULL COMMENT '订单编号,系统生成',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `pay_type` tinyint(2) DEFAULT '1' COMMENT '支付方式 0=线下支付，1=在线支付',
  `shipment_time` tinyint(2) DEFAULT NULL COMMENT '配送时间 1=不限送货时间，2=工作日送货，3=双休日、假日送货',
  `shipment_type` tinyint(2) DEFAULT '0' COMMENT '配送方式 0=快递配送（免运费），1=快递配送（运费）',
  `shipment_amount` decimal(10,0) DEFAULT '0' COMMENT '快递费',
  `invoice_type` tinyint(2) DEFAULT NULL COMMENT '支付方式 1=不开发票，2=电子发票，3=普通发票',
  `invoice_title` varchar(64) DEFAULT NULL COMMENT '发票抬头',
  `order_status` tinyint(2) DEFAULT NULL COMMENT '订单状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `order_amount` decimal(10,0) DEFAULT '0' COMMENT '订单金额',
  `order_score` int(11) DEFAULT '0' COMMENT '订单积分',
  `pay_amount` decimal(10,0) DEFAULT NULL COMMENT '支付金额 = 订单金额 + 快递费',
  `buy_number` int(11) DEFAULT NULL COMMENT '商品总数量',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8 COMMENT='订单表';

-- ----------------------------
-- Records of os_order
-- ----------------------------
INSERT INTO `os_order` VALUES ('1', '14907102171468493', '1', '1', '1', '1', '0', '1', null, '1', '2017-03-28 22:10:17', '2017-03-28 22:10:17', '24985', '25000', '24985', '15');
INSERT INTO `os_order` VALUES ('2', '14907103498114457', '1', '1', '1', '1', '0', '1', null, '3', '2017-03-28 22:12:30', '2017-03-28 22:12:30', '24985', '25000', '24985', '15');
INSERT INTO `os_order` VALUES ('3', '14907105253442098', '1', '1', '1', '1', '0', '1', null, '6', '2017-03-28 22:15:25', '2017-03-28 22:15:25', '24985', '25000', '24985', '15');
INSERT INTO `os_order` VALUES ('4', '14907114706600918', '1', '1', '1', '1', '0', '1', null, '12', '2017-03-28 22:31:11', '2017-03-28 22:31:11', '24985', '25000', '24985', '15');
INSERT INTO `os_order` VALUES ('5', '14944359894082287', '1', '1', '1', '1', '0', '1', null, '1', '2017-05-10 17:06:29', '2017-05-10 17:06:29', '14591', '14600', '14591', '9');
INSERT INTO `os_order` VALUES ('6', '14944360987092400', '1', '1', '1', '1', '0', '1', null, '1', '2017-05-10 17:08:19', '2017-05-10 17:08:19', '1599', '1600', '1599', '1');
INSERT INTO `os_order` VALUES ('7', '14944361196869580', '1', '1', '1', '1', '0', '1', null, '12', '2017-05-10 17:08:40', '2017-05-10 18:46:41', '1599', '1600', '1599', '1');
INSERT INTO `os_order` VALUES ('8', '14944369120266217', '1', '1', '1', '1', '0', '1', null, '12', '2017-05-10 17:21:52', '2017-05-10 18:44:56', '3198', '3200', '3198', '2');
INSERT INTO `os_order` VALUES ('9', '14944376560186831', '1', '1', '1', '1', '0', '1', null, '12', '2017-05-10 17:34:16', '2017-05-10 18:44:06', '1599', '1600', '1599', '1');
INSERT INTO `os_order` VALUES ('10', '14944390772967434', '1', '1', '1', '1', '0', '1', null, '1', '2017-05-10 17:57:57', '2017-05-10 17:57:57', '9843', '9848', '9843', '7');
INSERT INTO `os_order` VALUES ('11', '14944392556221620', '1', '1', '1', '1', '0', '1', null, '12', '2017-05-10 18:00:56', '2017-05-10 18:42:11', '1599', '1600', '1599', '1');
INSERT INTO `os_order` VALUES ('12', '14944739317304562', '1', '1', '3', '1', '0', '2', '陈星星', '1', '2017-05-11 03:38:52', '2017-05-11 05:53:17', '1828', '1829', '1828', '2');
INSERT INTO `os_order` VALUES ('13', '14944841433444157', '1', '1', '1', '1', '0', '1', null, '12', '2017-05-11 06:29:03', '2017-05-11 07:13:51', '5270', '5273', '5270', '5');
INSERT INTO `os_order` VALUES ('14', '14947730414380630', '1', '1', '1', '1', '0', '1', null, '1', '2017-05-14 14:44:01', '2017-05-14 14:44:01', '1599', '1600', '1599', '1');
INSERT INTO `os_order` VALUES ('18', '15025180252292837', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:07:05', null, '1599', '0', '1599', '1');
INSERT INTO `os_order` VALUES ('19', '15025181769174369', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:09:36', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('20', '15025183123016651', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:11:52', null, '1699', '0', '1699', '1');
INSERT INTO `os_order` VALUES ('21', '15025183964457327', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:13:16', null, '1699', '0', '1699', '1');
INSERT INTO `os_order` VALUES ('22', '15025184390653472', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:13:59', null, '1699', '0', '1699', '1');
INSERT INTO `os_order` VALUES ('23', '15025185087906518', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:15:08', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('24', '15025185287718511', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:15:28', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('25', '15025187148087712', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:18:42', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('26', '15025188773332167', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:21:17', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('27', '15025190011807402', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:23:21', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('29', '15025191375923310', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-12 14:25:37', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('30', '15025899883793633', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-13 10:06:28', null, '1997', '0', '1997', '3');
INSERT INTO `os_order` VALUES ('31', '15026075571077021', '1', '1', '1', '1', '0', '1', '', '1', '2017-08-13 14:59:17', null, '1599', '0', '1599', '1');
INSERT INTO `os_order` VALUES ('32', '15730126373195607', '31', '1', '1', '1', '0', '1', '', '1', '2019-11-06 11:57:17', null, '1699', '0', '1699', '1');
INSERT INTO `os_order` VALUES ('33', '15730896722468932', '32', '1', '2', '1', '0', '1', '', '1', '2019-11-07 09:21:12', null, '1699', '0', '1699', '1');
INSERT INTO `os_order` VALUES ('34', '15730983058648554', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-07 11:45:05', null, '3347', '0', '3347', '3');
INSERT INTO `os_order` VALUES ('35', '15736241406095459', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 13:49:00', null, '4726', '0', '4726', '4');
INSERT INTO `os_order` VALUES ('36', '15736259042248219', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:24', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('37', '15736259078515602', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:27', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('38', '15736259167408679', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:36', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('39', '15736259193768133', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:39', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('40', '15736259196715970', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:39', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('41', '15736259197928971', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:39', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('42', '15736259201225898', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:40', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('43', '15736259202229039', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:40', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('44', '15736259205837719', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:40', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('45', '15736259206927880', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:40', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('46', '15736259316234322', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:51', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('47', '15736259332655299', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:53', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('48', '15736259341217106', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:54', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('49', '15736259349237108', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:54', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('50', '15736259351991027', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:55', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('51', '15736259353378605', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:55', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('52', '15736259355689316', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:55', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('53', '15736259358761889', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:55', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('54', '15736259359883735', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:55', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('55', '15736259362622095', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:56', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('56', '15736259364729008', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:18:56', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('57', '15736259762717024', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:36', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('58', '15736259774171313', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:37', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('59', '15736259777013523', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:37', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('60', '15736259778255437', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:37', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('61', '15736259780834677', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:38', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('62', '15736259896689105', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:49', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('63', '15736259902273130', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:50', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('64', '15736259903462044', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:50', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('65', '15736259906044321', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:50', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('66', '15736259907329772', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:50', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('67', '15736259909818648', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:19:50', null, '1799', '0', '1799', '1');
INSERT INTO `os_order` VALUES ('68', '15736267095317568', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:49', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('69', '15736267119278781', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:51', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('70', '15736267122414873', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:52', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('71', '15736267123627217', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:52', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('72', '15736267126589090', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:52', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('73', '15736267127822035', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:52', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('74', '15736267131026826', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:53', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('75', '15736267132272517', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:53', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('76', '15736267135631667', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:53', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('77', '15736267136706391', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:53', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('78', '15736267168233205', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:56', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('79', '15736267171242408', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:57', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('80', '15736267172456507', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:57', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('81', '15736267175263704', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:57', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('82', '15736267176495939', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:57', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('83', '15736267180061011', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:58', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('84', '15736267181063291', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:58', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('85', '15736267184561934', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:58', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('86', '15736267185573563', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:58', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('87', '15736267189123316', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:58', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('88', '15736267190289214', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:59', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('89', '15736267192917593', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:59', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('90', '15736267195434901', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:59', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('91', '15736267197914057', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:31:59', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('92', '15736267201151066', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:00', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('93', '15736267202338280', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:00', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('94', '15736267204934024', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:00', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('95', '15736267208434152', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:00', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('96', '15736267209714423', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:00', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('97', '15736267213551163', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:01', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('98', '15736267214741193', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:01', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('99', '15736267217881535', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:01', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('100', '15736267221524894', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:02', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('101', '15736267222636812', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:02', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('102', '15736267226665057', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:02', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('103', '15736267227835555', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:02', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('104', '15736267231942776', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:03', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('105', '15736267233177156', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:03', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('106', '15736267237161018', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:03', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('107', '15736267238253824', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:03', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('108', '15736267242405639', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:04', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('109', '15736267243623692', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:04', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('110', '15736267247891513', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:04', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('111', '15736267249056588', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:04', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('112', '15736267252674116', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:05', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('113', '15736267253947271', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:05', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('114', '15736267256739945', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:32:05', null, '2028', '0', '2028', '2');
INSERT INTO `os_order` VALUES ('115', '15736278169622993', '32', '1', '1', '1', '0', '1', '', '1', '2019-11-13 14:50:16', null, '1828', '0', '1828', '2');
INSERT INTO `os_order` VALUES ('116', '15750267771706065', '35', '1', '1', '1', '0', '1', '', '1', '2019-11-29 19:26:17', null, '7196', '0', '7196', '4');
INSERT INTO `os_order` VALUES ('117', '15754282194318971', '35', '1', '1', '1', '0', '1', '', '1', '2019-12-04 10:56:59', null, '3198', '0', '3198', '2');
INSERT INTO `os_order` VALUES ('118', '15754451164115425', '37', '1', '1', '1', '0', '1', '', '1', '2019-12-04 15:38:36', null, '1799', '0', '1799', '1');

-- ----------------------------
-- Table structure for os_order_product
-- ----------------------------
DROP TABLE IF EXISTS `os_order_product`;
CREATE TABLE `os_order_product` (
  `order_product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单商品ID',
  `order_id` bigint(20) unsigned DEFAULT NULL COMMENT '订单ID',
  `product_number` bigint(20) unsigned DEFAULT NULL COMMENT '商品编号',
  `name` varchar(64) DEFAULT NULL COMMENT '商品名称',
  `pic_img` varchar(255) DEFAULT NULL COMMENT '展示图片',
  `product_spec_number` bigint(20) unsigned DEFAULT NULL COMMENT '商品规格编号',
  `product_spec_name` varchar(64) DEFAULT NULL COMMENT '商品规格名称',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `score` int(11) DEFAULT NULL COMMENT '积分',
  `buy_number` int(11) DEFAULT NULL COMMENT '商品总数量',
  `product_score` int(11) DEFAULT NULL COMMENT '商品总积分',
  `product_amount` decimal(10,0) DEFAULT NULL COMMENT '商品总金额',
  `comment_status` tinyint(2) DEFAULT '0' COMMENT '评论状态 0=未评论，1=已评论',
  `seller_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`order_product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COMMENT='订单明细表';

-- ----------------------------
-- Records of os_order_product
-- ----------------------------
INSERT INTO `os_order_product` VALUES ('1', '1', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '9', '14400', '14391', '0', '1');
INSERT INTO `os_order_product` VALUES ('2', '1', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207483', '白色 64G ', '1799.00', '1800', '5', '9000', '8995', '0', '1');
INSERT INTO `os_order_product` VALUES ('3', '1', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207484', '金色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('4', '2', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '9', '14400', '14391', '0', '1');
INSERT INTO `os_order_product` VALUES ('5', '2', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207483', '白色 64G ', '1799.00', '1800', '5', '9000', '8995', '0', '1');
INSERT INTO `os_order_product` VALUES ('6', '2', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207484', '金色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('7', '3', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '9', '14400', '14391', '0', '1');
INSERT INTO `os_order_product` VALUES ('8', '3', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207483', '白色 64G ', '1799.00', '1800', '5', '9000', '8995', '0', '1');
INSERT INTO `os_order_product` VALUES ('9', '3', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207484', '金色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('10', '4', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '9', '14400', '14391', '0', '1');
INSERT INTO `os_order_product` VALUES ('11', '4', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207483', '白色 64G ', '1799.00', '1800', '5', '9000', '8995', '0', '1');
INSERT INTO `os_order_product` VALUES ('12', '5', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '8', '12800', '12792', '0', '1');
INSERT INTO `os_order_product` VALUES ('13', '5', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207483', '白色 64G ', '1799.00', '1800', '1', '1800', '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('14', '6', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('15', '7', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('16', '8', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '2', '3200', '3198', '0', '1');
INSERT INTO `os_order_product` VALUES ('17', '9', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('18', '10', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '2', '3200', '3198', '0', '1');
INSERT INTO `os_order_product` VALUES ('19', '10', '1472581245880', '小米MIX', 'images/goods/20170226/1471798364441.jpg', '14725812458801', ' ', '1799.00', '1800', '3', '5400', '5397', '0', '1');
INSERT INTO `os_order_product` VALUES ('20', '10', '1472581300305', '魅蓝 Note5', 'images/goods/20170226/1471798388806.jpg', '1472581300305', ' ', '1099.00', '1099', '1', '1099', '1099', '0', '2');
INSERT INTO `os_order_product` VALUES ('21', '10', '1472583774201', '小米手环 2', 'images/goods/20170226/1471798568000.jpg', '1472583774201', ' ', '149.00', '149', '1', '149', '149', '0', '1');
INSERT INTO `os_order_product` VALUES ('22', '11', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('23', '12', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('24', '12', '1472583831117', '魅族手环', 'images/goods/20170226/1471798587971.jpg', '1472583831117', ' ', '229.00', '229', '1', '229', '229', '0', '2');
INSERT INTO `os_order_product` VALUES ('25', '13', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '2', '3200', '3198', '0', '1');
INSERT INTO `os_order_product` VALUES ('26', '13', '1472581245880', '小米MIX', 'images/goods/20170226/1471798364441.jpg', '14725812458801', ' ', '1799.00', '1800', '1', '1800', '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('27', '13', '1472583774201', '小米手环 2', 'images/goods/20170226/1471798568000.jpg', '1472583774201', ' ', '149.00', '149', '1', '149', '149', '0', '1');
INSERT INTO `os_order_product` VALUES ('28', '13', '1475353918562', '测试商品名称4', 'images/goods/20170226/1471797894441.jpg', '1475353918562', ' ', '124.00', '124', '1', '124', '124', '0', '3');
INSERT INTO `os_order_product` VALUES ('29', '14', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G ', '1599.00', '1600', '1', '1600', '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('33', '18', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G', '1599.00', null, '1', null, '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('34', '19', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207483', '白色 64G', '1799.00', null, '1', null, '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('35', '20', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207482', '白色 32G', '1699.00', null, '1', null, '1699', '0', '1');
INSERT INTO `os_order_product` VALUES ('36', '21', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207482', '白色 32G', '1699.00', null, '1', null, '1699', '0', '1');
INSERT INTO `os_order_product` VALUES ('37', '22', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207482', '白色 32G', '1699.00', null, '1', null, '1699', '0', '1');
INSERT INTO `os_order_product` VALUES ('38', '26', '1472581245880', '小米MIX', 'images/goods/20170226/1471798364441.jpg', '14725812458801', '', '1799.00', null, '1', null, '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('39', '27', '1472581245880', '小米MIX', 'images/goods/20170226/1471798364441.jpg', '14725812458801', '', '1799.00', null, '1', null, '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('41', '28', '1472581245880', '小米MIX', 'images/goods/20170226/1471798364441.jpg', '14725812458801', '', '1799.00', null, '1', null, '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('42', '29', '1472581245880', '小米MIX', 'images/goods/20170226/1471798364441.jpg', '14725812458801', '', '1799.00', null, '1', null, '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('43', '30', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207486', '金色 64G', '1799.00', null, '1', null, '1799', '0', '1');
INSERT INTO `os_order_product` VALUES ('44', '30', '1473318741286', 'Yeelight LED智能灯泡', 'images/goods/20170226/1471798581451.jpg', '1473318741286', '', '99.00', null, '2', null, '198', '0', '3');
INSERT INTO `os_order_product` VALUES ('45', '31', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G', '1599.00', null, '1', null, '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('46', '32', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207485', '金色 32G', '1699.00', null, '1', null, '1699', '0', '1');
INSERT INTO `os_order_product` VALUES ('47', '33', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207482', '白色 32G', '1699.00', null, '1', null, '1699', '0', '1');
INSERT INTO `os_order_product` VALUES ('48', '34', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G', '1599.00', null, '2', null, '3198', '0', '1');
INSERT INTO `os_order_product` VALUES ('49', '34', '1472583774201', '小米手环 2', 'images/goods/20170226/1471798568000.jpg', '1472583774201', '', '149.00', null, '1', null, '149', '0', '1');
INSERT INTO `os_order_product` VALUES ('50', '35', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207482', '白色 32G', '1699.00', null, '2', null, '3398', '0', null);
INSERT INTO `os_order_product` VALUES ('51', '35', '1472581300305', '魅蓝 Note5', 'images/goods/20170226/1471798388806.jpg', '1472581300305', '', '1099.00', null, '1', null, '1099', '0', null);
INSERT INTO `os_order_product` VALUES ('52', '35', '1472583831117', '魅族手环', 'images/goods/20170226/1471798587971.jpg', '1472583831117', '', '229.00', null, '1', null, '229', '0', null);
INSERT INTO `os_order_product` VALUES ('53', '115', '1472581220748', '小米手机5', 'images/goods/20170226/1471798318820.png', '14725812207481', '白色 16G', '1599.00', null, '1', null, '1599', '0', '1');
INSERT INTO `os_order_product` VALUES ('54', '115', '1472583831117', '魅族手环', 'images/goods/20170226/1471798587971.jpg', '1472583831117', '', '229.00', null, '1', null, '229', '0', '2');
INSERT INTO `os_order_product` VALUES ('55', '116', '1472581245880', '??MIX', 'images/goods/201901/1471798364441.jpg', '1472581245880', '', '1799.00', null, '4', null, '7196', '0', '1');
INSERT INTO `os_order_product` VALUES ('56', '117', '1472581220748', '????5', 'images/goods/201901/1471798318820.png', '14725812207481', '?? 16G', '1599.00', null, '2', null, '3198', '0', '1');
INSERT INTO `os_order_product` VALUES ('57', '118', '1472581245880', '小米MIX', 'images/goods/201901/1471798364441.jpg', '1472581245880', '', '1799.00', null, '1', null, '1799', '0', '1');

-- ----------------------------
-- Table structure for os_order_shipment
-- ----------------------------
DROP TABLE IF EXISTS `os_order_shipment`;
CREATE TABLE `os_order_shipment` (
  `order_shipment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '配送ID',
  `order_id` bigint(20) unsigned DEFAULT NULL COMMENT '订单ID',
  `user_name` varchar(64) DEFAULT NULL COMMENT '姓名',
  `user_phone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `user_adress` varchar(255) DEFAULT NULL COMMENT '详细地址',
  `user_zipcode` int(6) DEFAULT NULL COMMENT '邮政编码',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`order_shipment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='订单配送表';

-- ----------------------------
-- Records of os_order_shipment
-- ----------------------------
INSERT INTO `os_order_shipment` VALUES ('1', '1', '陈星星', '18857105127', '发烧发到斯蒂芬斯蒂芬', '123456', null);
INSERT INTO `os_order_shipment` VALUES ('2', '2', '陈星星', '18857105127', '发烧发到斯蒂芬斯蒂芬', '123456', null);
INSERT INTO `os_order_shipment` VALUES ('3', '3', '陈星星', '18857105127', '发烧发到斯蒂芬斯蒂芬', '123456', null);
INSERT INTO `os_order_shipment` VALUES ('4', '4', '陈星星', '18857105127', '发烧发到斯蒂芬斯蒂芬', '123456', null);
INSERT INTO `os_order_shipment` VALUES ('5', '5', '陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('6', '6', '陈星星', '18857105127', '大撒旦3d大苏打', '321231', null);
INSERT INTO `os_order_shipment` VALUES ('7', '7', '陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('8', '8', '陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('9', '9', '陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('10', '10', '陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('11', '11', '陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('12', '12', '陈星星陈星星', '18857105127', '海曙路58号', '123456', '2017-03-16 18:48:18');
INSERT INTO `os_order_shipment` VALUES ('13', '13', '陈星星', '18857105127', '大撒旦3d大苏打', '321231', null);
INSERT INTO `os_order_shipment` VALUES ('14', '14', '陈星星', '18857105127', '大撒旦3d大苏打', '321231', null);
INSERT INTO `os_order_shipment` VALUES ('18', '18', '陈星星', '18857105127', '大撒旦3d大苏打', '321231', null);
INSERT INTO `os_order_shipment` VALUES ('19', '19', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('20', '20', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('21', '21', '陈星星', '18857105127', '大撒旦3d大苏打', '321231', null);
INSERT INTO `os_order_shipment` VALUES ('22', '22', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('23', '26', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('24', '27', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('26', '29', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('27', '30', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('28', '31', '陈星星', '18857105127', '杭州师范大学仓前校区', '123456', '2017-05-10 15:39:11');
INSERT INTO `os_order_shipment` VALUES ('29', '32', '司法', '17853242597', '非机动车龙骑', '222111', null);
INSERT INTO `os_order_shipment` VALUES ('30', '33', '分众传媒', '17853242555', '奇马上发财', '222201', null);
INSERT INTO `os_order_shipment` VALUES ('31', '34', '分众传媒', '17853242555', '奇马上发财', '222333', null);
INSERT INTO `os_order_shipment` VALUES ('32', '35', '分众传媒', '17853242555', '奇马上发财', '222333', null);
INSERT INTO `os_order_shipment` VALUES ('33', '115', '分众传媒', '17853242555', '奇马上发财', '222333', null);
INSERT INTO `os_order_shipment` VALUES ('34', '116', '???', '17853243333', '??????????', '246543', null);
INSERT INTO `os_order_shipment` VALUES ('35', '117', 'Anna', '17853243333', '?????????', '256506', null);
INSERT INTO `os_order_shipment` VALUES ('36', '118', 'huxueke', '17853245555', '山东省滨州市博兴县', '256521', null);

-- ----------------------------
-- Table structure for os_order_status
-- ----------------------------
DROP TABLE IF EXISTS `os_order_status`;
CREATE TABLE `os_order_status` (
  `order_status_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单状态ID',
  `order_id` bigint(20) unsigned DEFAULT NULL COMMENT '订单ID',
  `order_status` tinyint(2) DEFAULT NULL COMMENT '订单状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_status` tinyint(2) DEFAULT NULL COMMENT '操作类型 0=会员，1=后台管理人员，2=异常通知',
  `remarks` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注信息',
  PRIMARY KEY (`order_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COMMENT='订单状态表';

-- ----------------------------
-- Records of os_order_status
-- ----------------------------
INSERT INTO `os_order_status` VALUES ('1', '1', '1', '2017-03-28 22:10:17', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('2', '2', '1', '2017-03-28 22:12:30', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('3', '3', '1', '2017-03-28 22:15:25', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('4', '4', '1', '2017-03-28 22:31:11', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('5', '4', '2', '2017-04-06 14:06:16', '0', '付款');
INSERT INTO `os_order_status` VALUES ('6', '4', '3', '2017-04-13 14:06:48', '0', '商家打包货物');
INSERT INTO `os_order_status` VALUES ('7', '4', '4', '2017-04-15 14:06:54', '0', '等待快递揽收');
INSERT INTO `os_order_status` VALUES ('8', '4', '5', '2017-05-03 14:07:04', '0', '快递运输途中');
INSERT INTO `os_order_status` VALUES ('9', '4', '6', '2017-05-10 14:07:09', '0', '已收货');
INSERT INTO `os_order_status` VALUES ('15', '5', '1', '2017-05-10 17:06:29', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('16', '6', '1', '2017-05-10 17:08:19', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('17', '7', '1', '2017-05-10 17:08:40', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('18', '8', '1', '2017-05-10 17:21:52', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('19', '9', '1', '2017-05-10 17:34:16', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('20', '10', '1', '2017-05-10 17:57:57', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('21', '11', '1', '2017-05-10 18:00:56', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('22', '11', '12', '2017-05-10 18:42:11', '0', '手动取消订单');
INSERT INTO `os_order_status` VALUES ('23', '9', '12', '2017-05-10 18:44:06', '0', '手动取消订单');
INSERT INTO `os_order_status` VALUES ('24', '8', '12', '2017-05-10 18:44:56', '0', '手动取消订单');
INSERT INTO `os_order_status` VALUES ('25', '7', '12', '2017-05-10 18:46:41', '0', '手动取消订单');
INSERT INTO `os_order_status` VALUES ('26', '12', '1', '2017-05-11 03:38:52', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('27', '13', '1', '2017-05-11 06:29:03', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('29', '14', '1', '2017-05-14 14:44:01', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('30', '18', '1', '2017-08-12 14:07:29', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('31', '19', '1', '2017-08-12 14:09:37', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('32', '20', '1', '2017-08-12 14:12:07', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('33', '21', '1', '2017-08-12 14:13:16', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('34', '22', '1', '2017-08-12 14:13:59', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('35', '26', '1', '2017-08-12 14:21:17', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('36', '27', '1', '2017-08-12 14:23:21', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('37', '28', '1', '2017-08-12 14:24:48', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('38', '29', '1', '2017-08-12 14:25:37', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('39', '30', '1', '2017-08-13 10:06:28', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('40', '31', '1', '2017-08-13 14:59:17', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('41', '32', '1', '2019-11-06 11:57:17', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('42', '33', '1', '2019-11-07 09:21:12', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('43', '34', '1', '2019-11-07 11:45:06', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('44', '35', '1', '2019-11-13 13:49:00', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('45', '115', '1', '2019-11-13 14:50:17', '0', '订单提交');
INSERT INTO `os_order_status` VALUES ('46', '116', '1', '2019-11-29 19:26:17', '0', '????');
INSERT INTO `os_order_status` VALUES ('47', '117', '1', '2019-12-04 10:56:59', '0', '????');
INSERT INTO `os_order_status` VALUES ('48', '118', '1', '2019-12-04 15:38:36', '0', '订单提交');

-- ----------------------------
-- Table structure for os_product
-- ----------------------------
DROP TABLE IF EXISTS `os_product`;
CREATE TABLE `os_product` (
  `product_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品ID',
  `product_number` bigint(20) unsigned DEFAULT NULL COMMENT '商品编号',
  `name` varchar(64) DEFAULT NULL COMMENT '商品名称',
  `show_price` decimal(10,2) DEFAULT NULL COMMENT '显示价格',
  `introduce` varchar(64) DEFAULT NULL COMMENT '商品简介',
  `pic_img` varchar(255) DEFAULT NULL COMMENT '展示图片',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `page_title` varchar(64) DEFAULT NULL COMMENT '页面标题',
  `page_description` varchar(255) DEFAULT NULL COMMENT '页面描述',
  `remarks` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注',
  `seller_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='商品表';

-- ----------------------------
-- Records of os_product
-- ----------------------------
INSERT INTO `os_product` VALUES ('1', '1472581220748', '小米手机5', '2299.00', '支持手机分身，能刷公交卡、银行卡', 'images/goods/201901/1471798318820.png', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '小米手机5', '小米手机5 十余项黑科技，很轻狠快。骁龙820处理器，最大可选4GB内存+128GB闪存，4轴防抖相机，3D陶瓷/玻璃机身。', null, '1');
INSERT INTO `os_product` VALUES ('2', '1472581245880', '小米MIX', '3499.00', '全面屏概念手机', 'images/goods/201901/1471798364441.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '小米MIX', '小米MIX 全面屏概念手机，开创性的在6.4寸超大屏幕上，做到了惊人的91.3%。当你点亮屏幕的一瞬间，200多万颗像素的色彩，开满了整个屏幕。', null, '1');
INSERT INTO `os_product` VALUES ('3', '1472581300305', '魅蓝 Note5', '1099.00', '快的更漂亮，薄的更持久', 'images/goods/201901/1471798388806.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '魅蓝 Note5', '魅蓝 Note5，正品行货，另有魅蓝 Note5详细介绍、图片、价格、参数、售前咨询等，购买魅蓝 Note5上魅族商城，全场包邮，7天无理由退货，15天换货保障。', null, '2');
INSERT INTO `os_product` VALUES ('4', '1472583774201', '小米手环 2', '149.00', '看得见的时刻，和你的每一步', 'images/goods/201901/1471798568000.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '小米手环2', '全新的小米手环 2，加入了 OLED 显示屏，通过轻触圆形按键，即可显示当前时间、步数、心率，甚至里程、热量等更多数据。当不方便触控操作时，抬起手腕，手环便可自动显示当前时间，轻松便捷。', null, '1');
INSERT INTO `os_product` VALUES ('5', '1472583831117', '魅族手环', '229.00', '腕间流动的心率专家', 'images/goods/201901/1471798587971.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '魅族手环', '魅族手环，腕间流动的心率专家，正品行货，另有魅族手环详细介绍、图片、价格、参数、售前咨询等，购买魅族手环上魅族商城，全场包邮，7天无理由退货，15天换货保障。', null, '2');
INSERT INTO `os_product` VALUES ('6', '1472628630086', 'LED 智能台灯', '169.00', '照明之上，光的艺术品', 'images/goods/201901/1471798587451.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', 'LED 智能台灯', '米家LED智能台灯的色温与亮度可以无级调节，几乎可以满足用户对光线的所有需求。还针对最常见的四种使用场景单独做了光线优化，专注保护用户的双眼。', null, '3');
INSERT INTO `os_product` VALUES ('7', '1472736931796', 'Yeelight床头灯', '249.00', '触摸式操作 给卧室1600万种颜色', 'images/goods/201901/1471799887971.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', 'Yeelight床头灯', '官网正品智能灯推荐，Yeelight床头灯最新价格249元，有多种颜色可选，另有Yeelight床头灯详细介绍及图片，还有用户评价，售前咨询等。', null, '3');
INSERT INTO `os_product` VALUES ('8', '1473318741286', 'Yeelight LED智能灯泡', '99.00', '亮度自由调节 WIFI远程操作', 'images/goods/201901/1471798581451.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', 'Yeelight LED智能灯泡', 'Yeelight LED 智能灯泡,亮度自由调节 WIFI远程操作', null, '3');
INSERT INTO `os_product` VALUES ('9', '1473685327798', '空气监测仪', '166.00', '全自动空气监测', 'images/goods/201901/029.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称1', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('10', '1474910562755', '智能电子秤', '223.00', '便利你的体质监测', 'images/goods/201901/031.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称2', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('11', '1475353900453', '智能婴儿称', '166.00', '无伤害监测婴儿的体制健康', 'images/goods/201901/032.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称3', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('12', '1475353918562', '戴尔笔记本', '3999.00', 'Dell/戴尔成就3000十代4核i5/i7Pcle固态盘2年服务多用笔记本电脑', 'images/goods/201901/033.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称4', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('13', '1475354006972', '游戏本笔记本', '4999.00', 'dell/戴尔灵越2019款新9代i5游匣G3吃鸡电竞游戏本办公轻薄便携手提学生笔记本电脑女生款3590窄边框高色域', 'images/goods/201901/034.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称5', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('14', '1475407186147', '戴尔酷睿', '5999.00', '酷睿13.3小屏512G大容量', 'images/goods/201901/035.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称6', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('15', '1475947762038', '心电图智能手表', '349.00', '喜荷心电图智能手表血压心率监测仪运动手环男多功能测高精度器老年人血氧健康心脏心跳量电子女华为小米通用', 'images/goods/201901/036.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称7', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('16', '1475996329018', '科智大功率移动电源', '129.00', '科智60000毫安超大容量聚合物充电宝双向快充自带线户外钓鱼移动电源适用苹果vivo华为oppo手机通用移动电源', 'images/goods/201901/037.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称8', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('17', '1477472951669', '荣耀路由器', '599.00', '华为旗下荣耀路由器Pro2全千兆家用无线双频Wifi智能上网5G信号双千兆端口穿墙王IPV6', 'images/goods/201901/038.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称9', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('18', '1478099883634', '公牛插座', '59.00', '公牛插座转换器无线插排家用多用功能一转多孔面板不带线插板插头', 'images/goods/201901/039.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称10', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('19', '1478522533460', '闪迪sd卡', '129.00', '手机相机行车仪128G大容量', 'images/goods/201901/040.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称11', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('20', '1478527872182', 'WD/西数移动硬盘', '399.00', '加密 智能备份 三年换新 兼容苹果 一键还原', 'images/goods/201901/041.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称12', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('21', '1478680540669', '蛇圣耳机', '223.00', '一机3用；镀银振膜；HIFI音质；轻便易携带', 'images/goods/201901/042.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称13', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('22', '1478682438293', '万魔活塞耳机', '2416.00', '活塞入耳式双系统线控耳机重低音', 'images/goods/201901/043.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称14', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('23', '1478682709405', '无线运动蓝牙耳机', '219.00', '石墨烯喇叭 金属腔体 24H无痛佩戴 狂甩不掉', 'images/goods/201901/044.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称15', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('24', '1478682831935', 'Golden Field/M16电脑音响', '295.00', '隐藏式不占空间/重低音/炫酷独立开关', 'images/goods/201901/045.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称16', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('25', '1478682893916', '笔记本小音响', '2164.00', '迷你桌面音箱便携即插即用声音大低音震', 'images/goods/201901/046.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称17', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('26', '1478683391099', '小米手机保护套', '20.90', '内置软套防摔 支架功能 送皮挂绳+贴膜', 'images/goods/201901/047.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称18', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('27', '1478683407372', '移动电源保护套', '26.00', '防刮 防尘 防摔 环保硅胶', 'images/goods/201901/048.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称19', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('28', '1478683468241', '行李箱拉杆箱', '399.00', '行李箱登机皮箱密码拉杆箱旅行箱子小型20女男24轻便万向轮大容量', 'images/goods/201901/049.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称20', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('29', '1478683468246', '商务拉杆箱', '265.00', '轻便商务经典设计防水耐磨正品专柜终身维修', 'images/goods/201901/050.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称21', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('30', '1478683468279', '双肩包男士', '200.00', '扩容双肩包男士背包商务休闲大容量出差旅行李包17寸笔记本电脑包\r\n扩容后变20寸拉杆箱大容量　防泼水面料', 'images/goods/201901/051.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称22', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('31', '1478689468277', '卫衣', '122.00', '长袖外套头卫衣定制diy同学聚会工作班服装来图定做圆领印字logo', 'images/goods/201901/052.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称23', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('32', '1478689468979', '测试商品名称24', '456.00', '测试描述，测试商品描述', 'images/goods/201901/1471797894441.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称24', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('33', '1478689448279', '测试商品名称25', '7845.00', '测试描述，测试商品描述', 'images/goods/201901/1471797894441.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称25', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('34', '1478689468679', '测试商品名称26', '1548.00', '测试描述，测试商品描述', 'images/goods/201901/1471797894441.jpg', '2017-02-25 21:44:43', '2017-02-25 21:44:48', '测试商品名称26', '测试商品页面描述,测试商品页面描述', '', null);
INSERT INTO `os_product` VALUES ('35', '1185345612051', '??pro', '2890.00', '?????', 'images/goods/20170226/001.jpg', null, null, '??', '????', null, '1');
INSERT INTO `os_product` VALUES ('36', '1105072365813', '??', '3999.00', '????', 'images/goods/201901/002.jpg', null, null, '??', '???????', null, '1');

-- ----------------------------
-- Table structure for os_product_category
-- ----------------------------
DROP TABLE IF EXISTS `os_product_category`;
CREATE TABLE `os_product_category` (
  `product_category_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品分类ID',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `category_id` bigint(20) DEFAULT NULL COMMENT '分类ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`product_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='商品分类关联表';

-- ----------------------------
-- Records of os_product_category
-- ----------------------------
INSERT INTO `os_product_category` VALUES ('1', '1', '33', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('2', '2', '33', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('3', '3', '12', '2017-02-27 01:51:36');
INSERT INTO `os_product_category` VALUES ('4', '4', '10', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('5', '5', '10', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('6', '6', '11', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('7', '7', '11', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('8', '8', '11', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('9', '9', '12', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('10', '10', '13', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('11', '11', '13', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('12', '12', '15', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('13', '13', '15', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('14', '14', '16', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('15', '15', '13', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('16', '16', '18', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('17', '17', '19', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('18', '18', '20', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('19', '19', '21', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('20', '20', '22', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('21', '21', '23', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('22', '22', '24', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('23', '23', '25', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('24', '24', '26', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('25', '25', '26', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('26', '26', '28', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('27', '27', '29', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('28', '28', '30', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('29', '29', '30', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('30', '30', '30', '2017-02-26 13:52:17');
INSERT INTO `os_product_category` VALUES ('31', '31', '31', '2017-02-26 13:52:17');

-- ----------------------------
-- Table structure for os_product_detail
-- ----------------------------
DROP TABLE IF EXISTS `os_product_detail`;
CREATE TABLE `os_product_detail` (
  `product_detail_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品描述ID',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `description` text COMMENT '商品描述',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`product_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='商品描述表';

-- ----------------------------
-- Records of os_product_detail
-- ----------------------------
INSERT INTO `os_product_detail` VALUES ('1', '1', '<p><img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_01.jpg\" src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_01.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_03.jpg\" src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_03.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_05.jpg\" src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_05.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_07.jpg\" src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_07.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_09.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_11.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_13.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_15.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_17.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_19.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_21.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_23.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_25.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_27.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_29.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_31.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_33.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_35.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_37.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_39.jpg\"> <img alt=\"\" data-src=\"//c1.mifile.cn/f/i/g/2015/cn-index/U1xingzhen_41.jpg\"></p>', '2017-04-14 02:16:57', '2017-04-14 02:17:05');

-- ----------------------------
-- Table structure for os_product_image
-- ----------------------------
DROP TABLE IF EXISTS `os_product_image`;
CREATE TABLE `os_product_image` (
  `pic_img_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品图片ID',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `pic_img` varchar(255) DEFAULT NULL COMMENT '展示图片',
  `sort` tinyint(2) DEFAULT NULL COMMENT '排序',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态：1.显示；0.隐藏',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`pic_img_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='商品图片表';

-- ----------------------------
-- Records of os_product_image
-- ----------------------------
INSERT INTO `os_product_image` VALUES ('1', '1', 'images/goods/201902/1471797894441.jpg', '1', '1', '2017-03-04 18:30:12');
INSERT INTO `os_product_image` VALUES ('2', '1', 'images/goods/201902/1471798318820.jpg', '2', '1', '2017-03-04 18:30:12');
INSERT INTO `os_product_image` VALUES ('3', '1', 'images/goods/201902/1471798364441.jpg', '3', '1', '2017-03-04 18:30:12');
INSERT INTO `os_product_image` VALUES ('4', '1', 'images/goods/201902/1471798581451.png', '4', '1', '2017-03-04 18:30:12');
INSERT INTO `os_product_image` VALUES ('5', '1', 'images/goods/201902/14717983642141.jpg', '5', '1', '2017-03-04 18:30:12');
INSERT INTO `os_product_image` VALUES ('6', '1', 'images/goods/201902/14717983642141.jpg', '6', '1', '2017-03-04 18:30:12');
INSERT INTO `os_product_image` VALUES ('7', '2', 'images/goods/201902/01.jpg', '7', '1', null);
INSERT INTO `os_product_image` VALUES ('8', '2', 'images/goods/201902/02.jpg', '8', '1', null);
INSERT INTO `os_product_image` VALUES ('9', '3', 'images/goods/201902/03.jpg', '9', '1', null);
INSERT INTO `os_product_image` VALUES ('10', '3', 'images/goods/201902/04.jpg', '10', '1', null);
INSERT INTO `os_product_image` VALUES ('11', '4', 'images/goods/201902/05.jpg', '11', '1', null);
INSERT INTO `os_product_image` VALUES ('12', '5', 'images/goods/201902/06.jpg', '12', '1', null);
INSERT INTO `os_product_image` VALUES ('13', '6', 'images/goods/201902/07.jpg', '13', '1', null);
INSERT INTO `os_product_image` VALUES ('14', '7', 'images/goods/201902/08.jpg', '14', '1', null);
INSERT INTO `os_product_image` VALUES ('15', '8', 'images/goods/201902/09.jpg', '15', '1', null);
INSERT INTO `os_product_image` VALUES ('16', '9', 'images/goods/201902/10.jpg', '16', '1', null);
INSERT INTO `os_product_image` VALUES ('17', '10', 'images/goods/201902/11.jpg', '17', '1', null);
INSERT INTO `os_product_image` VALUES ('18', '11', 'images/goods/201902/12.jpg', '18', '1', null);
INSERT INTO `os_product_image` VALUES ('19', '12', 'images/goods/201902/13.jpg', '19', '1', null);
INSERT INTO `os_product_image` VALUES ('20', '13', 'images/goods/201902/14.jpg', '20', '1', null);
INSERT INTO `os_product_image` VALUES ('21', '14', 'images/goods/201902/15.jpg', '21', '1', null);
INSERT INTO `os_product_image` VALUES ('22', '15', 'images/goods/201902/16.jpg', '22', '1', null);
INSERT INTO `os_product_image` VALUES ('23', '16', 'images/goods/201902/17.jpg', '23', '1', null);
INSERT INTO `os_product_image` VALUES ('24', '17', 'images/goods/201902/18.jpg', '24', '1', null);
INSERT INTO `os_product_image` VALUES ('25', '18', 'images/goods/201902/19.jpg', '25', '1', null);
INSERT INTO `os_product_image` VALUES ('26', '19', 'images/goods/201902/20.jpg', '26', '1', null);
INSERT INTO `os_product_image` VALUES ('27', '20', 'images/goods/201902/21.jpg', '27', '1', null);
INSERT INTO `os_product_image` VALUES ('28', '21', 'images/goods/201902/22.jpg', '28', '1', null);
INSERT INTO `os_product_image` VALUES ('29', '22', 'images/goods/201902/23.jpg', '29', '1', null);
INSERT INTO `os_product_image` VALUES ('30', '23', 'images/goods/201902/24.jpg', '30', '1', null);
INSERT INTO `os_product_image` VALUES ('31', '24', 'images/goods/201902/25.jpg', '31', '1', null);
INSERT INTO `os_product_image` VALUES ('32', '25', 'images/goods/201902/26.jpg', '32', '1', null);
INSERT INTO `os_product_image` VALUES ('33', '26', 'images/goods/201902/27.jpg', '33', '1', null);
INSERT INTO `os_product_image` VALUES ('34', '27', 'images/goods/201902/28.jpg', '34', '1', null);
INSERT INTO `os_product_image` VALUES ('35', '28', 'images/goods/201902/29.jpg', '35', '1', null);
INSERT INTO `os_product_image` VALUES ('36', '29', 'images/goods/201902/30.jpg', '36', '1', null);
INSERT INTO `os_product_image` VALUES ('37', '30', 'images/goods/201902/31.jpg', '37', '1', null);
INSERT INTO `os_product_image` VALUES ('38', '31', 'images/goods/201902/32.jpg', '38', '1', null);

-- ----------------------------
-- Table structure for os_product_parameter
-- ----------------------------
DROP TABLE IF EXISTS `os_product_parameter`;
CREATE TABLE `os_product_parameter` (
  `product_parameter_id` bigint(20) NOT NULL COMMENT '参数ID',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `name` varchar(64) DEFAULT NULL COMMENT '参数名',
  `value` varchar(64) DEFAULT NULL COMMENT '参数值',
  `sort` int(9) DEFAULT NULL COMMENT '排序',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`product_parameter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品参数表';

-- ----------------------------
-- Records of os_product_parameter
-- ----------------------------
INSERT INTO `os_product_parameter` VALUES ('1', '1', '处理器', '骁龙820', '1', '2017-03-04 18:55:19', '2017-03-04 18:55:29');
INSERT INTO `os_product_parameter` VALUES ('2', '1', '电池容量', '3000mAh', '2', '2017-03-04 18:55:19', '2017-03-04 18:55:29');
INSERT INTO `os_product_parameter` VALUES ('3', '1', '主屏尺寸', '5.15英寸', '3', '2017-03-04 18:55:19', '2017-03-04 18:55:29');
INSERT INTO `os_product_parameter` VALUES ('4', '1', '主屏分辨率', '1920x1080像素', '4', '2017-03-04 18:55:19', '2017-03-04 18:55:29');
INSERT INTO `os_product_parameter` VALUES ('5', '1', '后置摄像头', '1600万像素', '5', '2017-03-04 18:55:19', '2017-03-04 18:55:29');
INSERT INTO `os_product_parameter` VALUES ('6', '1', '前置摄像头', '400万像素', '6', '2017-03-04 18:55:19', '2017-03-04 18:55:29');
INSERT INTO `os_product_parameter` VALUES ('7', '1', '内存', '3GB', '7', '2017-03-04 18:55:19', '2017-03-04 18:55:29');

-- ----------------------------
-- Table structure for os_product_specification
-- ----------------------------
DROP TABLE IF EXISTS `os_product_specification`;
CREATE TABLE `os_product_specification` (
  `product_spec_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品规格ID',
  `product_spec_number` bigint(20) unsigned DEFAULT NULL COMMENT '商品规格编号',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `spec` varchar(64) DEFAULT NULL COMMENT '规格：规格ID，以“,”相隔',
  `stock` int(11) DEFAULT '0' COMMENT '库存',
  `sales_volume` int(11) DEFAULT '0' COMMENT '销售量',
  `price` decimal(10,2) DEFAULT NULL COMMENT '价格',
  `score` int(11) DEFAULT NULL COMMENT '积分',
  `default_status` tinyint(2) DEFAULT '0' COMMENT '是否默认状态：0,不默认；1,默认',
  `status` tinyint(2) DEFAULT '0' COMMENT '商品状态：0,新增；1,上架；2,下架',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`product_spec_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='商品规格表';

-- ----------------------------
-- Records of os_product_specification
-- ----------------------------
INSERT INTO `os_product_specification` VALUES ('1', '14725812207481', '1', '1,3', '40', '10', '1599.00', '1600', '1', '1', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('2', '14725812207482', '1', '1,4', '80', '20', '1699.00', '1700', '0', '1', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('3', '14725812207483', '1', '1,5', '100', '30', '1799.00', '1800', '0', '1', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('4', '14725812207484', '1', '2,3', '45', '45', '1599.00', '1600', '0', '1', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('5', '14725812207485', '1', '2,4', '12', '45', '1699.00', '1700', '0', '1', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('6', '14725812207486', '1', '2,5', '72', '75', '1799.00', '1800', '0', '0', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('7', '1472581245880', '2', '', '72', '75', '1799.00', '1800', '1', '1', '2017-03-05 21:51:01', '2017-03-05 21:51:25');
INSERT INTO `os_product_specification` VALUES ('8', '1472581300305', '3', null, '3', '3', '1099.00', '1099', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('9', '1472583774201', '4', null, '4', '4', '149.00', '149', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('10', '1472583831117', '5', null, '5', '5', '229.00', '229', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('11', '1472628630086', '6', null, '6', '6', '169.00', '169', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('12', '1472736931796', '7', null, '7', '7', '249.00', '249', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('13', '1473318741286', '8', null, '8', '8', '99.00', '99', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('14', '1473685327798', '9', null, '9', '9', '166.00', '166', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('15', '1474910562755', '10', null, '10', '10', '223.00', '223', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('16', '1475353900453', '11', null, '11', '11', '166.00', '166', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('17', '1475353918562', '12', null, '12', '12', '124.00', '124', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('18', '1475354006972', '13', null, '13', '13', '249.00', '249', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('19', '1475407186147', '14', null, '14', '14', '219.00', '219', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('20', '1475947762038', '15', null, '15', '15', '2366.00', '2366', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('21', '1475996329018', '16', null, '16', '16', '2499.00', '2499', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('22', '1477472951669', '17', null, '17', '17', '2188.00', '2188', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('23', '1478099883634', '18', null, '18', '18', '249.00', '249', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('24', '1478522533460', '19', null, '19', '19', '1300.00', '1300', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('25', '1478527872182', '20', null, '20', '20', '179.00', '179', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('26', '1478680540669', '21', null, '21', '21', '6429.00', '6429', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('27', '1478682438293', '22', null, '22', '22', '2416.00', '2416', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('28', '1478682709405', '23', null, '23', '23', '219.00', '219', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('29', '1478682831935', '24', null, '24', '24', '295.00', '295', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('30', '1478682893916', '25', null, '25', '25', '2164.00', '2164', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('31', '1478683391099', '26', null, '26', '26', '146.00', '146', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('32', '1478683407372', '27', null, '27', '27', '26.00', '26', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('33', '1478683468241', '28', null, '28', '28', '4974.00', '4974', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('34', '1478683468246', '29', null, '29', '29', '265.00', '265', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('35', '1478683468279', '30', null, '30', '30', '259.00', '259', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('36', '1478689468277', '31', null, '31', '31', '789.00', '789', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('37', '1478689468979', '32', null, '32', '32', '456.00', '456', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('38', '1478689448279', '33', null, '33', '33', '7845.00', '7845', '1', '1', null, null);
INSERT INTO `os_product_specification` VALUES ('39', '1478689468679', '34', null, '34', '34', '1548.00', '1548', '1', '1', null, null);

-- ----------------------------
-- Table structure for os_specification
-- ----------------------------
DROP TABLE IF EXISTS `os_specification`;
CREATE TABLE `os_specification` (
  `specification_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '规格ID',
  `category_id` bigint(20) DEFAULT NULL COMMENT '分类ID',
  `name` varchar(64) DEFAULT NULL COMMENT '规格名称',
  `status` tinyint(2) DEFAULT '1' COMMENT '状态：1.显示；0.隐藏',
  `sort` int(9) DEFAULT NULL COMMENT '排序',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`specification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='规格表\r\n';

-- ----------------------------
-- Records of os_specification
-- ----------------------------
INSERT INTO `os_specification` VALUES ('1', '2', '颜色', '1', '1', '2017-03-05 17:04:45', '2017-03-05 17:04:50');
INSERT INTO `os_specification` VALUES ('2', '2', '内存容量', '1', '2', '2017-03-05 17:07:17', '2017-03-05 17:07:22');

-- ----------------------------
-- Table structure for os_specification_attribute
-- ----------------------------
DROP TABLE IF EXISTS `os_specification_attribute`;
CREATE TABLE `os_specification_attribute` (
  `spec_attr_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '规格属性ID',
  `specification_id` bigint(20) DEFAULT NULL COMMENT '规格ID',
  `name` varchar(64) DEFAULT NULL COMMENT '规格属性名称',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`spec_attr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='规格属性表';

-- ----------------------------
-- Records of os_specification_attribute
-- ----------------------------
INSERT INTO `os_specification_attribute` VALUES ('1', '1', '白色', '2017-03-05 17:07:56');
INSERT INTO `os_specification_attribute` VALUES ('2', '1', '金色', '2017-03-05 17:08:09');
INSERT INTO `os_specification_attribute` VALUES ('3', '2', '16G', '2017-03-05 17:07:56');
INSERT INTO `os_specification_attribute` VALUES ('4', '2', '32G', '2017-03-05 17:08:09');
INSERT INTO `os_specification_attribute` VALUES ('5', '2', '64G', '2017-03-05 17:09:50');

-- ----------------------------
-- Table structure for os_user
-- ----------------------------
DROP TABLE IF EXISTS `os_user`;
CREATE TABLE `os_user` (
  `user_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `user_number` bigint(20) unsigned DEFAULT NULL COMMENT '用户编号',
  `user_name` varchar(30) DEFAULT NULL COMMENT '昵称',
  `login_password` varchar(32) DEFAULT NULL COMMENT '登录密码',
  `real_name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `sex` tinyint(1) DEFAULT '0' COMMENT '性别 0=保密/1=男/2=女',
  `age` tinyint(4) DEFAULT '0' COMMENT '年龄',
  `pic_img` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态 0=冻结/1=正常',
  `telephone` varchar(11) DEFAULT NULL COMMENT '手机号码',
  `regeist_time` datetime DEFAULT NULL COMMENT '注册时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- ----------------------------
-- Records of os_user
-- ----------------------------
INSERT INTO `os_user` VALUES ('1', '14875975007231277', '穿鞋子的猫', '123456', '陈星星', '0', '0', 'default/avatar/avatar_8.jpg', '1', '18857105127', '2017-02-21 15:19:07', '2017-02-24 01:53:02');
INSERT INTO `os_user` VALUES ('8', '148777295260796', '陈星星', '123456', '陈星星', '0', '0', 'default/avatar/avatar_4.jpg', '1', '18857105120', '2017-02-22 22:15:53', null);
INSERT INTO `os_user` VALUES ('12', '148777481346536', '陈星星', '123456', '陈星星', '0', '0', 'default/avatar/avatar_5.jpg', '1', '18857105137', '2017-02-22 22:46:53', null);
INSERT INTO `os_user` VALUES ('28', '149165425386333', '陈星星', '123456', '陈星星', '0', '0', 'default/avatar/avatar_7.jpg', '1', '18857105165', '2017-04-08 12:24:14', '2017-04-18 08:05:39');
INSERT INTO `os_user` VALUES ('29', '149165425386388', '康健', '123456', null, '0', '0', null, '1', '17853242111', null, null);
INSERT INTO `os_user` VALUES ('30', '15588711558055888', '??999_mt', 'mt123456', null, '0', '0', null, '1', '17853243093', null, null);
INSERT INTO `os_user` VALUES ('31', '15736171415355919', '刘刘刘', 'mm123456', null, '0', '0', null, '1', '17853242222', null, null);
INSERT INTO `os_user` VALUES ('32', '15736183981983794', '在那个', 'mm123456', null, '0', '0', null, '1', '17853242777', null, null);
INSERT INTO `os_user` VALUES ('33', '15743011686462460', 'huxueke', 'hxk123456', null, '0', '0', null, '1', '17853241111', null, null);
INSERT INTO `os_user` VALUES ('34', '15743013019415238', 'huke', 'hxk123456', null, '0', '0', null, '1', '17853242222', null, null);
INSERT INTO `os_user` VALUES ('35', '15743053259715298', 'huxuekkk', 'hxk333', null, '0', '0', null, '1', '17853243333', null, null);
INSERT INTO `os_user` VALUES ('36', '15752540803603364', 'wangsenming', 'hxk444', null, '0', '0', null, '1', '1785324444', null, null);
INSERT INTO `os_user` VALUES ('37', '15754450506239431', '小胡', 'hxk555', null, '0', '0', null, '1', '17853245555', null, null);

-- ----------------------------
-- Table structure for seller
-- ----------------------------
DROP TABLE IF EXISTS `seller`;
CREATE TABLE `seller` (
  `seller_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '商家id',
  `seller_name` varchar(30) DEFAULT NULL COMMENT '昵称',
  `telephone` varchar(11) DEFAULT NULL COMMENT '编号',
  `login_password` varchar(32) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`seller_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of seller
-- ----------------------------
INSERT INTO `seller` VALUES ('1', '王王王', '17853242333', '123456', '3000.00');
INSERT INTO `seller` VALUES ('2', '李李李', '17853242444', '123456', '4000.00');
INSERT INTO `seller` VALUES ('3', '马马马', '17853242555', '123456', '5000.00');
