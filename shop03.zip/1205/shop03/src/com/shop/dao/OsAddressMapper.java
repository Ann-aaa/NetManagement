package com.shop.dao;

import com.shop.po.OsAddress;

import java.util.List;

public interface OsAddressMapper {
	
}