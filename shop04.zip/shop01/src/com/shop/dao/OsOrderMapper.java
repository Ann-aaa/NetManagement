package com.shop.dao;

import com.shop.po.OsOrder;
import com.shop.vo.OrderVO;

import java.util.List;

public interface OsOrderMapper {
}