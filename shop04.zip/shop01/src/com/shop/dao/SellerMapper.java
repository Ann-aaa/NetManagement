package com.shop.dao;


import com.shop.po.Seller;

public interface SellerMapper {
}