package com.shop.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.shop.po.OsProductDetail;
import com.shop.util.GetRandom;
import com.shop.vo.KindVO;

import net.sf.json.JSONObject;

import org.apache.hadoop.hive.ql.parse.HiveParser_IdentifiersParser.intervalLiteral_return;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shop.po.OsCategory;
import com.shop.po.OsProduct;
import com.shop.po.OsProductCategory;
import com.shop.po.OsProductImage;
import com.shop.po.OsProductParameter;
import com.shop.po.OsProductSpecification;
import com.shop.po.OsUser;
import com.shop.po.Seller;
import com.shop.service.OsCategoryService;
import com.shop.service.OsProductService;
import com.shop.vo.HotCategoryVO;

@Controller
public class OsProductController {

	@Autowired
    OsProductService osProductService;
	@Autowired
    OsCategoryService osCategoryService;
	
	
	
	
	// 首页热门分类
	@RequestMapping("/recommend/hot")
	public String recommendTop(HttpServletRequest request) {
		ArrayList<HotCategoryVO> categorys = osProductService.getHotCategory();
		request.setAttribute("categorys", categorys);
		return "/recommend/recommend_hot";
	}

	// 商品详情
	@RequestMapping("/detail/{productNumber}")
	public String productDetail(HttpServletRequest request, @PathVariable Long productNumber) {
		//信息
		OsProduct osProduct = osProductService.getProductDetil(productNumber);
		//商品详细介绍
		OsProductDetail detail = osProductService.getProductDetail(osProduct.getProductId());
		//图片
		List<OsProductImage> productImages = osProductService.getProductImages(osProduct.getProductId());
		//参数
		List<OsProductParameter> productParameter = osProductService.getProductParameter(osProduct.getProductId());
		//规格
		List<KindVO> kindVOs = osProductService.getProductKind(osProduct.getProductId());
		Map<String, Object> map =  osProductService.getProductSpecification(osProduct.getProductId());
		request.setAttribute("product",osProduct);
		request.setAttribute("detail",detail);
		request.setAttribute("productImages",productImages);
		request.setAttribute("productParameter",productParameter);
		request.setAttribute("kindVOs",kindVOs);
		request.setAttribute("productSpecifications", JSONObject.fromObject(map));
		return "/product/product_detail";
	}
	
	
	
	
	
	@RequestMapping( "/product/insert")
    public String insertProduct(@RequestParam("proname") String proname, 
    		@RequestParam("proprice") String proprice, 
    		@RequestParam("prointro") String prointro, 
    		@RequestParam("proimage") String proimage, 
    		@RequestParam("protitle") String protitle, 
    		@RequestParam("prodescription") String prodescription, 
    		@RequestParam("procatrgory") String procatrgory, 
    		@RequestParam("prostock") String prostock, 
    		@RequestParam("proscore") String proscore, 
    		 HttpSession session,HttpServletRequest request) {
		
		
		OsProduct product = new OsProduct();
		//Long num = GetRandom.getNumber();
		Long num = getRandom(13);
		product.setProductNumber(num);
		product.setName(proname);
		BigDecimal showPrice = new BigDecimal (proprice);
		product.setShowPrice(showPrice);
		product.setIntroduce(prointro);
		product.setPicImg("images/goods/201901/"+proimage+".jpg");
		product.setPageTitle(protitle);
		product.setPageDescription(prodescription);
		Seller seller =(Seller) session.getAttribute("seller");
		product.setSellerId(seller.getSellerId());
		int result =osProductService.insertProduct(product);
		if(0!=result){
		
		OsCategory category = osCategoryService.getByCategoryName(procatrgory);
		OsProductCategory procateCategory = new OsProductCategory();
		procateCategory.setCategoryId(category.getCategoryId());
		procateCategory.setProductId(osProductService.selectProductIdByNameAndSellerId(proname,seller.getSellerId()));
		osProductService.insertProductCategory(procateCategory);
		
		OsProductSpecification productSpecification =new  OsProductSpecification();
		productSpecification.setProductId(osProductService.selectProductIdByNameAndSellerId(proname,seller.getSellerId()));
		productSpecification.setScore(Integer.valueOf(proscore));
		productSpecification.setPrice(showPrice);
		productSpecification.setStock(Integer.valueOf(prostock));
		productSpecification.setProductSpecNumber(num);
		osProductService.insertOsProductSpecification(productSpecification);
                return "redirect:/index"; 
		}else{
			return "redirect:/user/user_login";
		}
	}
	
	@RequestMapping("/insertpro")
    public String insertPro(HttpServletRequest request) {
        return "/product/product_insert";
    }
	
	public static  Long getRandom(int length){
		String val="";
		Random random = new Random();
		for(int i=0;i<length;i++){
			val+=String.valueOf(random.nextInt(10));
		}
		return Long.valueOf(val);
	}
	
}
