package com.shop.controller;

import com.shop.po.OsUser;
import com.shop.service.OsOrderService;
import com.shop.vo.OrderVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping(value = "/uc/order")
public class OsOrderOperationController {

    @Autowired
    private OsOrderService orderService;

    @RequestMapping(value = "/list")
    public String orderUI(HttpSession session, HttpServletRequest request,
                          @RequestParam(value = "page", required = false, defaultValue = "1") Integer page,
                          @RequestParam(value = "limit", required = false, defaultValue = "8") Integer limit) {
        OsUser user = (OsUser) session.getAttribute("user");
        List<OrderVO> orderVOs = orderService.getPageOrderByUserId(user.getUserId(), page, limit);
        com.shop.common.PageInfo info = new  com.shop.common.PageInfo(page.intValue(), limit.intValue(), "", "");

        info.setTotal((int) orderService.getL().getTotal());
        request.setAttribute("pageInfo", info);
        request.setAttribute("orderVOs", orderVOs);
        return "/usercenter/user_order";
    }

    @RequestMapping(value = "//{orderNumber}")
    public String orderUI(@PathVariable Long orderNumber, HttpSession session, HttpServletRequest request) {
        OrderVO orderVO = orderService.getOrderByOrderNumber(orderNumber);
        request.setAttribute("orderVO", orderVO);
        return "/usercenter/user_order_view";
    }



}
