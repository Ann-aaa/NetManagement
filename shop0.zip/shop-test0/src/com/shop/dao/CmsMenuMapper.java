package com.shop.dao;

import com.shop.po.CmsMenu;

public interface CmsMenuMapper {
}