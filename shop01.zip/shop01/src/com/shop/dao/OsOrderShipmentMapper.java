package com.shop.dao;

import com.shop.po.OsOrderShipment;

public interface OsOrderShipmentMapper {
}