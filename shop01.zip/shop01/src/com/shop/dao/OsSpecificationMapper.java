package com.shop.dao;

import com.shop.po.OsSpecification;

public interface OsSpecificationMapper {
}