package com.shop.dao;

import com.shop.po.OsUser;

public interface OsUserMapper {
}