package com.shop.dao;

import com.shop.po.OsSpecificationAttribute;

public interface OsSpecificationAttributeMapper {

}