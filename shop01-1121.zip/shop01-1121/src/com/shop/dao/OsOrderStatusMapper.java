package com.shop.dao;

import com.shop.po.OsOrderStatus;

public interface OsOrderStatusMapper {
}