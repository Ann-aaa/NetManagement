package com.shop.dao;

import com.shop.po.OsOrderProduct;

import java.util.List;

public interface OsOrderProductMapper {
    
}