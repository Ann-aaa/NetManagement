package com.shop.common;

public interface ReturnCode {

    public Integer getCode();

	public String getMessage();
	
}